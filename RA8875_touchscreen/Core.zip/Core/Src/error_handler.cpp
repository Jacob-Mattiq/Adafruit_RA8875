/*
 * error_handler.cpp
 *
 *  Created on: Dec 7, 2024
 *      Author: jarla
 */

#include "error_handler.hpp"

extern "C" {
void Error_Handler(void)
	{
		while(1) {}
	}
}
