/*
 * error_handler.hpp
 *
 *  Created on: Dec 7, 2024
 *      Author: jarla
 */

#ifndef INC_HPP_ERROR_HANDLER_HPP_
#define INC_HPP_ERROR_HANDLER_HPP_

extern "C" {
	void Error_Handler(void);
}

#endif /* INC_HPP_ERROR_HANDLER_HPP_ */
